from django.urls import path
from .views import StateListView, StateDetailView, StateCreateView, StateUpdateView, StateDeleteView

urlpatterns = [
    path('', StateListView.as_view(), name='state_list'),
    path('state/<int:pk>/', StateDetailView.as_view(), name='state_detail'),
    path('state/new/', StateCreateView.as_view(), name='state_new'),
    path('state/edit/<int:pk>/', StateUpdateView.as_view(), name='state_edit'),
    path('state/delete/<int:pk>/', StateDeleteView.as_view(), name='state_delete'),
]